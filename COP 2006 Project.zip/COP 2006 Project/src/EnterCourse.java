import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.IOException;

public class EnterCourse {
    /**
     *
     * @throws FileNotFoundException
     */
    public static void enterClass() throws FileNotFoundException {
        //user selects class they're entering grades for
        Scanner scan = new Scanner(System.in);

        //prints course options
        System.out.println("\nEnter a course from the list:\n ");
        String[] classes = {"Science", "Math", "Art",};
        for (String s : classes) {
            System.out.println(s);
        }
        System.out.println();

        //course is capitalized for file entry
        String courseOneTest1 = scan.nextLine().toLowerCase();
        String courseOneTest2 = courseOneTest1.substring(0, 1).toUpperCase();
        String courseOne = courseOneTest2 + courseOneTest1.substring(1).toLowerCase();

        //user's entered class is compared to see if a valid option choice
        boolean courseFound = false;
        for (int i = 0; i <= classes.length - 1; i++) {
            if (courseOne.contains(classes[i])) {
                System.out.println(courseOne);
                courseFound = true;
            }
        }
         if (courseFound == false) {
            System.out.println("\n" + courseOne + " isn't an option");
            return;
        }

        //chosen course is checked to see if it's already in gradebook.txt
        Scanner regScan = new Scanner(new File("gradebook.txt"));
        while (regScan.hasNextLine()) {
            String line = regScan.nextLine();
            //finds name in file if there
            if (line.contains(courseOne)) {
                System.out.println("\nThat course has already been entered, please select a new one");
                return;
            }
        }

        //append course name to file
        try {
            FileWriter gradeBook = new FileWriter("gradebook.txt", true);
            gradeBook.write("Subject: " + courseOne + "\n");
            gradeBook.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        //sends to grade entry for selected course
        CalculateGrades enterGrades = new CalculateGrades();
        CalculateGrades.enterGrades();
    }
}
