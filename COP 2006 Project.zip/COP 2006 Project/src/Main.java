import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        /*
         * Beginning part: asks for name and purpose of using program
         */

        Scanner scan = new Scanner(System.in);

        //name is capitalized for file entry
        System.out.println("Enter your first name: ");
        String userFirstName1 = scan.nextLine();
        String userFirstName2 = userFirstName1.substring(0, 1).toUpperCase();
        String userFirstName = userFirstName2 + userFirstName1.substring(1).toLowerCase();
        System.out.println("Enter your last name: ");
        String userLastName1 = scan.nextLine();
        String userLastName2 = userLastName1.substring(0, 1).toUpperCase();
        String userLastName = userLastName2 + userLastName1.substring(1).toLowerCase();

        //checks if name is already in gradebook.txt
        boolean namePresent = false;

        Scanner scanv2 = new Scanner(new File("gradebook.txt"));
        while (scanv2.hasNextLine()) {
            String line = scanv2.nextLine();
            if (line.contains(userFirstName)) {
                namePresent = true;
                break;
            }
        }

        //append name to file, if not already there
        if (namePresent == false) {
            try {
                FileWriter gradeBook = new FileWriter("gradebook.txt");
                gradeBook.write("\n\n" + userFirstName + " " + userLastName + "\n\n");
                gradeBook.close();
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }

        //asks for user's purpose
        int userPurpose = 0;
        while (userPurpose == 0) {
            System.out.println("\nEnter [1] to search for old grades \nEnter [2] to enter new grades");
            userPurpose = scan.nextInt();
            if (userPurpose == 1) {
                if (namePresent == true) {
                    //reads gradeBook
                    ParseFile readFile = new ParseFile();
                    ParseFile.parseFile(userFirstName);
                } else {
                    System.out.println("\nThere are no records under that name");
                }
            } else if (userPurpose == 2) {
                //initiates EnterCourse
                EnterCourse gradesClass = new EnterCourse();
                EnterCourse.enterClass();

                //asks for more courses and grades
                boolean answerChoice = true;
                while (answerChoice == true) {
                    scan = new Scanner(System.in);
                    System.out.printf("\nWould you like to enter another course? Y/N\n");
                    String anotherCourse = scan.nextLine().toLowerCase();
                    //anotherCourse = scan.nextLine().toLowerCase();
                    switch (anotherCourse) {
                        case "y", "yes":
                            //adds another course under their name
                            EnterCourse.enterClass();
                            continue;
                        case "n", "no":
                            answerChoice = false;
                    }
                }
                System.out.println("\nDo you want to see your past entry? Y/N\n");
                scan = new Scanner(System.in);
                String answer = scan.nextLine().toLowerCase();;
                switch (answer) {
                    case "y", "yes":
                        //reads gradeBook
                        System.out.println();
                        ParseFile readFile = new ParseFile();
                        ParseFile.parseFile(userFirstName);
                    case "n", "no":
                        break;
                }
            } else {
                System.out.println("That wasn't a valid answer choice, try again");
                userPurpose = 0;
            }
        }
    }
}
