import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;

public class ParseFile {
    /**
     * @param searchName
     * @throws FileNotFoundException
     */
    public static void parseFile (String searchName) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("gradebook.txt"));
        boolean nameRead = false;

        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            //print following information under user's name
            if (nameRead == true) {
                System.out.println(line);
            }
            //finds name in file
            if (line.contains(searchName)) {
                System.out.println("\n" + line);
                nameRead = true;
            }
        }
    }
}
